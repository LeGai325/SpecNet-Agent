#!/usr/bin/env python3
"""Validate packaged profile structure without printing record contents."""

from __future__ import annotations

import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROFILES = {
    "trace_driven_v1": ROOT / "external_agent_data/processed/trace_driven_v1/profile.json",
    "trace_driven_v2": ROOT / "external_agent_data/processed/trace_driven_v2/profile.json",
    "trace_driven_v3_candidate": (
        ROOT / "external_agent_data/processed/trace_driven_v3_candidate/profile.json"
    ),
}
SUSPICIOUS = re.compile(
    r"(?:/Users/|/home/|\bsk-[A-Za-z0-9_-]{20,}\b|\bgho_[A-Za-z0-9]+\b|\bhf_[A-Za-z0-9]+\b)"
)


def string_audit(value: object) -> tuple[int, int]:
    suspicious = 0
    longest = 0
    stack = [value]
    while stack:
        current = stack.pop()
        if isinstance(current, dict):
            stack.extend(current.keys())
            stack.extend(current.values())
        elif isinstance(current, list):
            stack.extend(current)
        elif isinstance(current, str):
            longest = max(longest, len(current))
            suspicious += bool(SUSPICIOUS.search(current))
    return suspicious, longest


for expected_id, path in PROFILES.items():
    profile = json.loads(path.read_text(encoding="utf-8"))
    assert profile.get("profile_id") == expected_id, (path, profile.get("profile_id"))
    suspicious, longest = string_audit(profile)
    assert suspicious == 0, f"{path}: suspicious string matches={suspicious}"
    print(
        f"OK {expected_id}: bytes={path.stat().st_size}, "
        f"suspicious_strings=0, max_string_length={longest}"
    )
