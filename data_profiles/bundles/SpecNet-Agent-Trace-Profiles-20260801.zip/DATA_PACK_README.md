# SpecNet-Agent Trace Profiles 数据包

生成日期：2026-08-04  
冻结数据版本：2026-08-01  
适用代码：SpecNet-Agent PR #3 或合并后的 `main`

## 包含内容

```text
external_agent_data/
└── processed/
    ├── trace_driven_v1/profile.json
    ├── trace_driven_v2/profile.json
    └── trace_driven_v3_candidate/profile.json
```

这三个文件是用于模拟器的脱敏、数值化 profile，不包含原始 prompt、完整对话、tool
arguments、本机路径或原始 session/repo/user ID。原始公开数据没有放入本压缩包。

## 最快使用方式

将压缩包解压到 `SpecNet-Agent` 仓库根目录，使仓库内出现
`external_agent_data/processed/...`，然后执行：

```bash
cd /path/to/SpecNet-Agent
export SPECNET_DATA_ROOT="$PWD/external_agent_data"
```

运行 V3 smoke：

```bash
python3 specnet_agent_experiments/specnet_agent_experiment.py \
  --workload-profile trace_driven_v3_candidate \
  --output-dir outputs/v3_candidate_smoke \
  --train-episodes 3 \
  --eval-runs 1 \
  --duration 800 \
  --max-workflows 30 \
  --max-time 2500
```

需要 V2 时把 `--workload-profile` 改为 `trace_driven_v2`；V1 对应
`trace_driven_v1` 或 `trace_driven_v1_1`。

## 校验

在压缩包解压位置执行：

```bash
shasum -a 256 -c SHA256SUMS
python3 audit_profiles.py
```

checksum 三项和 profile 审计都显示 `OK` 才表示数据包完整。

## 数据来源与使用边界

- TraceLab v0.0.1：CC-BY-4.0；
- BurstGPT v2.0：CC-BY-4.0；
- RAGPulse revision `3672232d45d749fdcf45dbc38cc77e5264af4a32`：MIT；
- SWE-chat revision `f66cca95b14caaa4177f7ed5eaa424608dadcffa`：ODC-BY。

本数据包用于课题组内部复现实验。V3 是真实数据校准的固定模板 workload，不是生产日志
回放；deadline、网络 telemetry、queue 和 action 反事实仍由模拟器提供。若需公开再分发，
应保留上述来源、版本和许可证说明。
